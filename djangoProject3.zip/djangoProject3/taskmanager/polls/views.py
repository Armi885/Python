from django.shortcuts import render
from django.http import HttpResponse, Http404

def index(request):
    donates = Donate.objects.all()
    template = loader.get_template('donates/index.html')
    context = {
        'donates': donates,
    }
    return HttpResponse(template.render(context, request))